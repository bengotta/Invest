const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.post('/create', async (req, res) => {
  const { userId, planAmount } = req.body;

  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ error: 'User not found' });

  const investment = {
    planAmount,
    dailyRate: 10,
    startDate: new Date()
  };

  user.investments.push(investment);
  await user.save();

  res.json({ message: 'Investment recorded', investment });
});

router.get('/return/:userId', async (req, res) => {
  const { userId } = req.params;

  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ error: 'User not found' });

  let totalReturn = 0;
  const now = new Date();

  user.investments.forEach(inv => {
    const days = Math.floor((now - new Date(inv.startDate)) / (1000 * 60 * 60 * 24));
    const earned = inv.planAmount * (1 + (inv.dailyRate / 100) * days);
    totalReturn += earned;
  });

  res.json({ totalReturn });
});

module.exports = router;
