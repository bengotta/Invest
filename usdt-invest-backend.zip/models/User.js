const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: String,
  password: String,
  referralCode: String,
  referredBy: String,
  walletAddress: String,
  investments: [
    {
      planAmount: Number,
      dailyRate: Number,
      startDate: Date
    }
  ]
});

module.exports = mongoose.model('User', userSchema);
